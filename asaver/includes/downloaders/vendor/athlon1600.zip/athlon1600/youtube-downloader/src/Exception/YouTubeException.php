<?php

namespace YouTube\Exception;

class YouTubeException extends \Exception
{

}