<?php

namespace YouTube\Responses;

class VideoPlayerJs extends HttpResponse
{
}